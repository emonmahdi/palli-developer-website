new Typed("#typed-text", {
    strings: ["Better Future", "Smarter Homes", "Stronger Communities"],
    typeSpeed: 90,
    backSpeed: 50,
    loop: true
  });